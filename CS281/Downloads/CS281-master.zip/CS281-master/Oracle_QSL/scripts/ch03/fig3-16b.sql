SELECT *
FROM null_sample
WHERE invoice_total = 0
