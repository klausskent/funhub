SELECT 'test'  AS test_string, 
       10-7    AS test_calculation, 
       SYSDATE AS test_date
FROM Dual