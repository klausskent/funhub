SELECT invoice_number, invoice_date, invoice_total 
FROM invoices
WHERE invoice_total > 50000
