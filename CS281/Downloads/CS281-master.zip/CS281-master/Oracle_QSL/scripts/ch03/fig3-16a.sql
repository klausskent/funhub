-- use the EX connection
SELECT *
FROM null_sample
