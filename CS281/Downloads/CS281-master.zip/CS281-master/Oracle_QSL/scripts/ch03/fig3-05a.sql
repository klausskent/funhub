SELECT vendor_city, vendor_state, vendor_city || vendor_state
FROM vendors