DROP TABLE invoices_copy
