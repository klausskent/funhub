DROP TABLE old_invoices
