DROP TABLE vendor_balances
