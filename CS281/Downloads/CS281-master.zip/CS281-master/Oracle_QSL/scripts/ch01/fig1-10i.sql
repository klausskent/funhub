DROP SEQUENCE invoice_id_seq
