SELECT * FROM vendors_min
