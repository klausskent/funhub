-- NOTE: This doesn't work due to foreign key constraint
DELETE FROM invoices
WHERE invoice_number = '4-342-8069'
