CREATE VIEW vendors_min AS
    SELECT vendor_name, vendor_state, vendor_phone
    FROM vendors
