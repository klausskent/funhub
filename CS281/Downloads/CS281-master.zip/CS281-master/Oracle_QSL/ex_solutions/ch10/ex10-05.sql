CREATE SEQUENCE member_id_seq
  START WITH 3;
CREATE SEQUENCE group_id_seq
  START with 3;