DELETE FROM invoices
WHERE invoice_id = 115
