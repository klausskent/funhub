CONNECT ap/ap;
CREATE USER tom IDENTIFIED BY temp;
GRANT payment_entry TO tom;