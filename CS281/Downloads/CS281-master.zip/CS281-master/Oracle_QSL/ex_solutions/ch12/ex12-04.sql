SELECT * FROM user_role_privs;
SELECT * FROM role_sys_privs;
SELECT * FROM role_tab_privs;