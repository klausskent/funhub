SELECT *
FROM open_items_summary
WHERE ROWNUM <= 5