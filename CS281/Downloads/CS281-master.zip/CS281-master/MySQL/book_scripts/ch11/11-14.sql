SHOW CHARSET;

SHOW CHARSET LIKE 'latin1';

SHOW COLLATION;

SHOW COLLATION LIKE 'latin1%';

SHOW VARIABLES LIKE 'character_set_server';

SHOW VARIABLES LIKE 'collation_server';

SHOW VARIABLES LIKE 'character_set_database';

SHOW VARIABLES LIKE 'collation_database';