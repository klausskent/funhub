SELECT * FROM mysql.general_log;

SELECT * FROM mysql.slow_log;
