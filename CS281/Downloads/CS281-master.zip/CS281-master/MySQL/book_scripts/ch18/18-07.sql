SELECT User, Host FROM mysql.user;
 
SHOW GRANTS FOR jim;
 
SHOW GRANTS FOR ap_user@localhost;
 
SHOW GRANTS;
