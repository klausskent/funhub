REVOKE ALL, GRANT OPTION 
FROM jim;

REVOKE ALL, GRANT OPTION 
FROM ap_admin, joel@localhost;

REVOKE UPDATE, DELETE
ON ap.invoices FROM joel@localhost